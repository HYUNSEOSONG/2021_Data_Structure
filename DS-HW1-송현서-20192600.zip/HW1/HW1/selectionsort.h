#pragma once
#include <iostream>
#include "Pharmacy.h"
using namespace std;

void swapElements_selection(Pharmacy a[], int first, int last);
int maxSelect(Pharmacy a[], int n);
void SelectionSort(Pharmacy a[], int n);