#include "Pharmacy.h"
#include<string.h>
using namespace std;

Pharmacy::Pharmacy()
{
	name = " ";
	distance = 0;
	remains = 0;
	arr_time = 0;
}

Pharmacy::Pharmacy(string m_name, int m_distance, int m_remains, int m_arr_time)
{
	name = m_name;
	distance = m_distance;
	remains = m_remains;
	arr_time = m_arr_time;
}

Pharmacy::~Pharmacy()
{
}


string Pharmacy::getName()
{
	return name;
}

int Pharmacy::getDistance()
{
	return distance;
}

int Pharmacy::getRemains()
{
	return remains;
}

int Pharmacy::getArr_time()
{
	return arr_time;
}

void Pharmacy::setName(string m_name)
{
	name = m_name;
}

void Pharmacy::setDistance(int m_distance)
{
	distance = m_distance;
}

void Pharmacy::setRemains(int m_remains)
{
	remains=m_remains;
}

void Pharmacy::setArr_time(int m_arr_time)
{
	arr_time = m_arr_time;
}