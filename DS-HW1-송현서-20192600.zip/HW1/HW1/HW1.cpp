﻿// HW1.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//
#include <iostream>
using namespace std;
#include <string>
#include "Pharmacy.h"
#include "selectionsort.h"
#include "Binary_search.h"
#include "Quick_sort.h"
void print(Pharmacy a[], int last);
//크기를 10으로 지정
const int SIZE = 10;

int main()
//main 함수에서 10명의 약국의 array를 지정한다.
//멤버변수는 약국이름, 거리, 마스크 보유잔량, 마스크 도착시간이다. 
{   //이름순으로 정렬 될 array
    Pharmacy pharmacy_1[10] = { 
        Pharmacy("가약국",3,20,1030),
        Pharmacy("마약국",4,19,1525),
        Pharmacy("나약국",8,18,1343),
        Pharmacy("사약국",6,17,2123),
        Pharmacy("파약국",8,16,1098),
        Pharmacy("라약국",4,15,1242),
        Pharmacy("바약국",5,14,1523),
        Pharmacy("아약국",6,13,1234),
        Pharmacy("차약국",7,12,1645),
        Pharmacy("자약국",8,11,1253) };
    //original array
    Pharmacy pharmacy_2[10] = {
        Pharmacy("가약국",3,20,1030),
        Pharmacy("마약국",4,19,1525),
        Pharmacy("나약국",8,18,1343),
        Pharmacy("사약국",6,17,2123),
        Pharmacy("파약국",8,16,1098),
        Pharmacy("라약국",4,15,1242),
        Pharmacy("바약국",5,14,1523),
        Pharmacy("아약국",6,13,1234),
        Pharmacy("차약국",7,12,1645),
        Pharmacy("자약국",8,11,1253) };

    cout << "문제 2----------\n" << endl;
    cout << "<약국 array>\n";
    //main 함수에서 열 명의 약국을 array로 생성한다. 
    //그리고 화면에 생성된 약국을 화면에 보여준다.
    //selection sort를 구현하고 이름 순으로 원래 array를 정렬하고 화면에 보여준다 
    print(pharmacy_1, SIZE);
    cout << "\n";
    //selectionsort
    cout << "<이름 순으로 정렬 후 array>\n";
    for (int i = 0;i < SIZE - 1;i++) {
        SelectionSort(pharmacy_1, SIZE - i);
    }
    print(pharmacy_1, SIZE);
    cout << "==============================================================================" << endl;
 
    cout << "문제 3-------------\n";
    //"사 약국"과 "하 약국" 두개의 약국을 BinarySerach를 이용하여 인덱스 위치를 받고 이를 출력한다.
    //만약 데이터에 없는 값일 때, '실패'가 출력되도록 한다.
    cout << " " << endl;
    //binary search 
    cout << "<데이터에 있는 '사 약국' 찾기>" << endl;
    Pharmacy aPharmacy("사약국", 6, 17, 2123);
    int location1 = BinarySearch(pharmacy_1, SIZE, aPharmacy);
    if (location1 == -1) {
        cout << "실패\n" << endl;
    }
    else {
        cout << "타겟 저장 인덱스: " << location1<<"\n";
    }
    cout << "<데이터에 없는 '하 약국' 찾기>" << endl;
    Pharmacy bPharmacy("하약국", 8, 30, 2143);
    int location2;
    location2 = BinarySearch(pharmacy_1, SIZE, bPharmacy);
    if (location2 == -1) {
        cout << "실패\n" << endl;
    }
    else {
        cout << "타겟 저장 인덱스: " << location2;
    }
    cout << "================================================================================" << endl;
    
    cout << "문제 4-------------\n" << endl;
    //quicksort를 이용하여 가장 많은 마스크 잔량을 갖고 있는 순서로 약국을 정렬한다.
    
    int pharmacy_1_compareCount = 0;
    int pharmacy_1_swapCount = 0;
    int pharmacy_1_calculateCount = 0;
    quicksort(pharmacy_1, 0, SIZE - 1, pharmacy_1_compareCount, pharmacy_1_swapCount, pharmacy_1_calculateCount);
    print(pharmacy_1, SIZE);

    //pharmacy_2 quicksort(5번과 연관)
    int pharmacy_original_compareCount = 0;
    int pharmacy_original_swapCount = 0;
    int pharmacy_original_calculateCount = 0;
    quicksort(pharmacy_1, 0, SIZE - 1, pharmacy_original_compareCount, pharmacy_original_swapCount, pharmacy_original_calculateCount);
    cout << "===================================================================================" << endl;
    cout << "문제5-----------\n" << endl;
    //처음 초기화한 원래의 array를 pharmacy_2라 하고, 이를 quicksort 했을때 연산개수와 문제 2번에서 이름순으로 sort된 pahrmacy_1을 quicksort 했을 때 연산개수를 비교한다. 
    cout << "<원래 array를 quicksort했을 때, 비교문, 산술문, swap횟수>\n";
    cout << "비교문 횟수 : " << pharmacy_original_compareCount << endl;
    cout << "swap 횟수: " << pharmacy_original_swapCount << endl;
    cout << "산술문 횟수: " << pharmacy_original_calculateCount << endl;
    int pharmacy_original_sum = pharmacy_original_compareCount + pharmacy_original_swapCount + pharmacy_original_calculateCount;
    cout << "실제 연산 갯수 : " << pharmacy_original_sum << endl;
    cout << " " << endl;
    cout << "이름으로 정렬된 array를 quicksort했을 때, 비교문, 산술문, swap횟수>\n";
    cout << "비교문 횟수 : " << pharmacy_1_compareCount << endl;
    cout << "swap 횟수 : " << pharmacy_1_swapCount << endl;
    cout << "산술문 횟수 : " << pharmacy_1_calculateCount << endl;
    int pharmacy_info_sum = pharmacy_1_compareCount + pharmacy_1_swapCount + pharmacy_1_calculateCount;
    cout << "실제 연산 갯수 : " << pharmacy_info_sum << endl;
    cout << "\n";
    
    cout << "나의 의견: quicksort를 할때 최악의 경우는 이미 정렬이 되어있는 경우이고, 이름 순으로 정렬전의 array는 이미 Mask Remains이 내림차순으로 정렬되어있기 때문에 연산 횟수가 더 많다.";
    cout << "\n";
}
void print(Pharmacy a[], int last) {
    int i;
    for (i = 0;i < last;i++) {
        cout << "name : " << a[i].getName() << ", Distance : " << a[i].getDistance() <<
            ", Mask Remains : " << a[i].getRemains() << ", Mask Arrive Time : " << a[i].getArr_time() << endl;
    }
}