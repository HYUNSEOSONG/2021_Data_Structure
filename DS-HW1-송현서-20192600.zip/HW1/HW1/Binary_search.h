#pragma once
#include <iostream>
#include "Pharmacy.h"
using namespace std;

int BinarySearch(Pharmacy a[], int n, Pharmacy target);